package dev.deathclient.mod;

import com.mojang.blaze3d.systems.RenderSystem;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Path;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Manages custom cape texture loading and registration.
 * 
 * Similar approach to SkinManager:
 *   1. Reads a cape PNG from disk (expected: 64×32)
 *   2. Registers it as a dynamic texture
 *   3. The mixin (AbstractClientPlayerMixin) redirects cape rendering
 *      to use our registered texture Identifier
 * 
 * Cape texture is registered under:
 *   death-client-mod:textures/cape/custom_cape
 * 
 * Elytra texture is also overridden to match the cape (same file).
 */
public class CapeManager {

    private static final CapeManager INSTANCE = new CapeManager();
    private static final class_2960 CAPE_TEXTURE_ID = class_2960.method_60655(DeathClientMod.MOD_ID, "textures/cape/custom_cape");

    private boolean hasCape = false;
    private boolean textureRegistered = false;
    private Path currentCapePath = null;
    private class_1043 capeTexture = null;

    private CapeManager() {}

    public static CapeManager getInstance() {
        return INSTANCE;
    }

    /**
     * Load a cape PNG from the given path and register it as a Minecraft texture.
     */
    public void loadCape(Path capePath) {
        this.currentCapePath = capePath;

        class_310 client = class_310.method_1551();
        if (client == null) {
            this.hasCape = true;
            DeathClientMod.LOGGER.info("[Death Client/CapeManager] Marked cape for deferred loading: {}", capePath);
            return;
        }

        if (!RenderSystem.isOnRenderThread()) {
            RenderSystem.recordRenderCall(() -> registerTexture(capePath));
            this.hasCape = true;
        } else {
            registerTexture(capePath);
        }
    }

    private void registerTexture(Path capePath) {
        try {
            disposeTexture();

            InputStream is = new FileInputStream(capePath.toFile());
            class_1011 image = class_1011.method_4309(is);
            is.close();

            int w = image.method_4307();
            int h = image.method_4323();

            // Standard cape dimensions: 64×32 or multiples (some HD capes use 2048×1024)
            if (h != 32 && h != 64 && w != 64 && w != 128) {
                DeathClientMod.LOGGER.warn("[Death Client/CapeManager] Cape has unusual dimensions: {}×{}", w, h);
            }

            // Create and register the texture safely crossing obfuscation discrepancies
            try {
                capeTexture = new class_1043(image);
            } catch (Throwable e) {
                for (java.lang.reflect.Constructor<?> c : class_1043.class.getConstructors()) {
                    if (c.getParameterCount() == 1) {
                        capeTexture = (class_1043) c.newInstance(image);
                        break;
                    }
                }
                if (capeTexture == null) throw new RuntimeException("Could not reflective construct NativeImageBackedTexture", e);
            }
            class_310.method_1551().method_1531().method_4616(CAPE_TEXTURE_ID, capeTexture);
            textureRegistered = true;
            hasCape = true;

            DeathClientMod.LOGGER.info("[Death Client/CapeManager] Cape texture registered: {} ({}×{})", CAPE_TEXTURE_ID, w, h);
        } catch (Exception e) {
            DeathClientMod.LOGGER.error("[Death Client/CapeManager] Failed to register cape texture", e);
            hasCape = false;
            textureRegistered = false;
        }
    }

    public void ensureTextureRegistered() {
        if (hasCape && !textureRegistered && currentCapePath != null) {
            registerTexture(currentCapePath);
        }
    }

    private void disposeTexture() {
        if (capeTexture != null) {
            try {
                class_310 client = class_310.method_1551();
                if (client != null && client.method_1531() != null) {
                    client.method_1531().method_4615(CAPE_TEXTURE_ID);
                }
            } catch (Exception ignored) {}
            capeTexture = null;
            textureRegistered = false;
        }
    }

    public void clearCape() {
        disposeTexture();
        hasCape = false;
        currentCapePath = null;
        DeathClientMod.LOGGER.info("[Death Client/CapeManager] Cape cleared.");
    }

    // --- Accessors ---

    public boolean hasCape() {
        return hasCape;
    }

    public boolean isTextureReady() {
        return hasCape && textureRegistered;
    }

    public class_2960 getCapeTextureId() {
        return CAPE_TEXTURE_ID;
    }

    public Path getCapePath() {
        return currentCapePath;
    }
}
