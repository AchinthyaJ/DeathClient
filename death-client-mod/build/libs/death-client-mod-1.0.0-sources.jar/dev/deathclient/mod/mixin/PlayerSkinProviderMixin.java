package dev.deathclient.mod.mixin;

import dev.deathclient.mod.DeathClientMod;
import dev.deathclient.mod.SkinManager;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_640;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Mixin into PlayerListEntry to override skin texture resolution.
 * 
 * HOOK POINT: PlayerListEntry#getSkinTextures()
 * 
 * This is where Minecraft resolves the skin texture for a given player.
 * By injecting at the RETURN of this method, we can replace the skin
 * Identifier in the returned SkinTextures with our custom texture —
 * but ONLY for the local player.
 * 
 * Why PlayerListEntry?
 *   In modern Minecraft (1.20+), skin textures flow through:
 *     PlayerListEntry → SkinTextures → PlayerEntityRenderer
 *   This is the cleanest interception point because:
 *   - It's called every frame during rendering
 *   - It returns a SkinTextures record that bundles skin + cape + model
 *   - We can construct a new SkinTextures with our overrides
 * 
 * Why not SkinProvider/SkinTexture?
 *   - SkinProvider deals with fetching from Mojang's API (irrelevant offline)
 *   - Direct texture replacement would affect ALL players on a LAN server
 */
@Mixin(class_640.class)
public abstract class PlayerSkinProviderMixin {

    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void deathClient_overrideSkinTextures(CallbackInfoReturnable<class_8685> cir) {
        SkinManager skinMgr = SkinManager.getInstance();

        if (!skinMgr.hasSkin()) return;

        // Only override for the local player
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) return;

        class_640 self = (class_640) (Object) this;
        
        // Get the player's profile from the entry
        if (client.field_1724.method_7334() == null) return;
        
        // Check if this entry belongs to the local player
        class_640 localEntry = client.method_1562() != null 
            ? client.method_1562().method_2871(client.field_1724.method_5667()) 
            : null;
        
        if (localEntry == null || self != localEntry) return;

        // Ensure texture is registered (handles deferred loading)
        skinMgr.ensureTextureRegistered();
        if (!skinMgr.isTextureReady()) return;

        class_8685 original = cir.getReturnValue();
        if (original == null) return;

        // Build new SkinTextures with our custom skin
        class_2960 customSkinId = skinMgr.getSkinTextureId();
        
        class_8685 overridden = new class_8685(
            customSkinId,                       // skin texture → OUR custom texture
            original.comp_1911(),              // textureUrl (unused in rendering)
            original.comp_1627(),             // cape texture (CapeManager handles this)
            original.comp_1628(),           // elytra texture
            original.comp_1629(),                   // model type (wide/slim) 
            original.comp_1630()                   // secure flag
        );

        cir.setReturnValue(overridden);
    }
}
