package dev.deathclient.mod.mixin;

import dev.deathclient.mod.CapeManager;
import dev.deathclient.mod.DeathClientMod;
import dev.deathclient.mod.SkinManager;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Mixin into AbstractClientPlayerEntity to override cape texture.
 * 
 * HOOK POINT: AbstractClientPlayerEntity#getSkinTextures()
 * 
 * Why a separate mixin for capes?
 *   PlayerListEntry and AbstractClientPlayerEntity both have getSkinTextures(),
 *   but the cape rendering pipeline specifically uses the player entity's method.
 *   By intercepting here, we ensure cape overrides work in ALL contexts:
 *   - Third-person view
 *   - Elytra rendering
 *   - Tab list player head (if supported)
 * 
 * The cape Identifier is inserted into the SkinTextures alongside any
 * skin overrides from PlayerSkinProviderMixin. Both mixins work together:
 *   1. PlayerSkinProviderMixin replaces skin in PlayerListEntry
 *   2. This mixin replaces cape in AbstractClientPlayerEntity
 *   
 * Since AbstractClientPlayerEntity.getSkinTextures() typically delegates
 * to PlayerListEntry.getSkinTextures(), our skin override flows through
 * automatically. This mixin only needs to handle the CAPE injection.
 */
@Mixin(class_742.class)
public abstract class AbstractClientPlayerMixin {

    @Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
    private void deathClient_overrideCapeTexture(CallbackInfoReturnable<class_8685> cir) {
        CapeManager capeMgr = CapeManager.getInstance();
        SkinManager skinMgr = SkinManager.getInstance();

        boolean hasCape = capeMgr.hasCape();
        boolean hasSkin = skinMgr.hasSkin();

        // Nothing to override
        if (!hasCape && !hasSkin) return;

        // Only override for the local player
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1724 == null) return;

        class_742 self = (class_742) (Object) this;
        if (self != client.field_1724) return;

        class_8685 original = cir.getReturnValue();
        if (original == null) return;

        // Ensure textures are registered (deferred loading)
        if (hasCape) capeMgr.ensureTextureRegistered();
        if (hasSkin) skinMgr.ensureTextureRegistered();

        // Determine what to override
        class_2960 skinTexture = original.comp_1626();
        class_2960 capeTexture = original.comp_1627();
        class_2960 elytraTexture = original.comp_1628();

        // Override skin if available
        if (hasSkin && skinMgr.isTextureReady()) {
            skinTexture = skinMgr.getSkinTextureId();
        }

        // Override cape and elytra if available
        if (hasCape && capeMgr.isTextureReady()) {
            class_2960 customCapeId = capeMgr.getCapeTextureId();
            capeTexture = customCapeId;
            elytraTexture = customCapeId; // Elytra uses the same texture as cape
        }

        // Only create a new SkinTextures if something actually changed
        if (skinTexture != original.comp_1626() || capeTexture != original.comp_1627()) {
            class_8685 overridden = new class_8685(
                skinTexture,
                original.comp_1911(),
                capeTexture,
                elytraTexture,
                original.comp_1629(),
                original.comp_1630()
            );
            cir.setReturnValue(overridden);
        }
    }
}
